import json,sys,copy
from pathlib import Path
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-access-spec.json').read_text());p=m.Planner(s['board'])
changed={};s['vias']=[v for v in s['vias'] if v['name'] not in ['C5 local return','U3 local return']]
new_escapes={'U1.24 escape':[173,113.0],'U1.16 control escape':[177,112.95],'U1.20 control escape':[175.4,112.7],'U1.22 control escape':[174.1,112.9]}
for v in s['vias']:
 if v['name'] in new_escapes:
  old=v['at'];v['at']=new_escapes[v['name']];changed[tuple(old)]=v['at']
 if 'bus east transition' in v['name']:
  old=v['at'];v['at']=[old[0],107.65];changed[tuple(old)]=v['at']
for r in s['paths']:r['through']=[changed.get(tuple(x),x) if isinstance(x,list) else x for x in r['through']]
s['paths']=[r for r in s['paths'] if r['name'] not in ['C5.2 local return','U3.2 local return','C6.1 to C5.1','C4.2 to U3.2']]
local=[]
for pin,at in [('C5.2',[174.7,112.0]),('U3.2',[176.1,110.1]),('C4.2',[179.5,112.3])]:
 v={'name':pin+' ground return','net':'GND','at':at};s['vias'].append(v);local.append({'name':pin+' ground return','net':'GND','width':.3,'through':[pin,at],'layer':'F.Cu'})
local.append({'name':'C6.1 to C5.1','net':'VDD_3V3','width':.3,'through':['C6.1','C5.1'],'layers':['F.Cu','B.Cu'],'bounds':[168,108,179,115],'join_existing_copper':True})
keys=[]
for name,at in [('U1.3 to SW1.2',[164.5,119.7]),('U1.4 to SW2.2',[164.5,118.7]),('U1.5 to SW3.2',[164.5,117.7])]:
 r=next(r for r in s['paths'] if r['name']==name);s['paths'].remove(r)
 s['vias'].append({'name':name+' southwest transition','net':r['net'],'at':at})
 first=copy.deepcopy(r);first.update(name=name+' module traverse',through=[r['through'][0],at],bounds=[161,118.9 if r['net']!='KEY_OK_N' else 117.4,183,124.8],end_layer='B.Cu');keys.append(first)
 last=copy.deepcopy(r);last.update(name=name+' button side',through=[at,r['through'][1]],start_layer='F.Cu',end_layer='F.Cu',layers=['F.Cu'],bounds=[145,111,166,127.7]);keys.append(last)
# The three key crossings stay below the display/USB entrance.
front=[];rest=[]
for r in s['paths']:
 if 'escape' in r['name'] or 'access' in r['name'] or 'transverse bus' in r['name'] or len(r.get('layers',[r.get('layer','F.Cu')]))==1:front.append(r)
 else:rest.append(r)
s['paths']=local+front+keys+rest
for v in s['vias']:
 error=p.add_via(v)
 if error:print(error);raise SystemExit('Invalid via')
s['description']='Northeast regulator group with separate southern key crossings and physical transverse control buses';s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/wholeboard-east-apply.json'
(b/'wholeboard-east-spec.json').write_text(json.dumps(s,indent=2)+'\n')
