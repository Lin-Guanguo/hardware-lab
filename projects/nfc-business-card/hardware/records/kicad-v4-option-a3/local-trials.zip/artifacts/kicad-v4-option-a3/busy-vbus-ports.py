import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,child
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
plan=json.load(open('projects/nfc-business-card/hardware/kicad/v4-option-a2-full/successful-batch-plan.json'));oldids=json.load(open('projects/nfc-business-card/hardware/records/kicad-v4-option-a2/full-successful-batch-ipc.json'))['created_ids'];ids=[];i=0
for r in plan['routes']:
 n=len(r['points'])-1
 if r['name']=='VBUS MCU branch':ids+=oldids[i:i+n]
 i+=n
for v in plan['vias']:
 if v['net']=='USB_VBUS' and 173<v['at'][0]<179:ids.append(oldids[i])
 i+=1
ids=[x for x in ids if x not in {'161e4f19-015d-4ae0-943f-d5aa6802a5ec','2070dbba-9937-452e-b369-e163d6d9cf7e','b8e725fd-b7e5-4d55-8463-bfcd2fb3d582','6e17724c-c205-4408-ab59-c8a0792bfe70'}]
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ['segment','via'] and child(x,'uuid')[1] in ids)]
model=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/busy-vbus-ports-model.kicad_pcb');write(model,b)
s=importlib.util.spec_from_file_location('rt','projects/nfc-business-card/scripts/route-v4-octilinear.py');rt=importlib.util.module_from_spec(s);s.loader.exec_module(rt);r=rt.Planner(model);fail=[]
requests=[dict(name='BUSY escape after removing enclosing VBUS branch',net='EPD_BUSY_TBD',width=.15,through=['U1.24','J2.9'],layers=['F.Cu','B.Cu'],bounds=[163.5,94,180,116],join_existing_copper=True),dict(name='BUSY pullup local connection',net='EPD_BUSY_TBD',width=.15,through=['J2.9','R18.2'],layers=['F.Cu','B.Cu'],bounds=[163,86,175,99],join_existing_copper=True),dict(name='VBUS MCU branch rebuilt with BUSY present',net='USB_VBUS',width=.25,through=['C8.1','C1.1'],layers=['F.Cu','B.Cu'],bounds=[166,102,182,115],join_existing_copper=True)]
for q in requests:
 e=r.route(q);print(q['name'],e or 'routed',flush=True)
 if e:fail.append({'name':q['name'],**e})
result=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 jointly repair only BUSY and the eleven-segment VBUS branch proven to enclose its MCU exit',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/busy-vbus-ports-ipc.json',remove_trial_ids=ids,routes=r.routes,vias=r.vias,failures=fail)
(p/'busy-vbus-ports-plan.json').write_text(json.dumps(result,indent=2)+'\n')
