import sys,json
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
s=json.load(open('projects/nfc-business-card/hardware/kicad/v4-phase3/wholeboard-crossing-spec.json'));p=m.Planner(s['board'])
for v in s['vias']:p.add_via(v)
for n,at in [('SWDCLK',[167.1,121.5]),('SWDCLK',[166.5,119.5]),('SWDIO',[167.1,120.5]),('SWDIO',[167.2,118.95])]:
 print(n,at,p.add_via({'name':n+' bridge','net':n,'at':at}))
