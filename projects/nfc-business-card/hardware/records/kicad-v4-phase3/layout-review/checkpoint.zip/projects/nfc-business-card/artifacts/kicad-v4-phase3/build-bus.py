import sys,json,copy
from pathlib import Path
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-crossing-spec.json').read_text());p=m.Planner(s['board'])
changes={'SWDIO':([168.351,122.134],[167.2,118.95]),'SWDCLK':([167.451,122.434],[166.5,119.5])}
for v in s['vias']:
 if v['net'] in changes and v['at']==changes[v['net']][0]:v['at']=changes[v['net']][1]
for r in s['paths']:
 if r['net'] in changes:r['through']=[changes[r['net']][1] if x==changes[r['net']][0] else x for x in r['through']]
for v in s['vias']:
 err=p.add_via(v)
 if err:print(err)
buses=[];connections=[]
for i,name in enumerate(['R5.2 to U1.19','R8.2 to U1.20','R6.2 to U1.16','R9.2 to U1.21','R7.2 to U1.22']):
 r=next(r for r in s['paths'] if r['name']==name);y=105.5+.36*i;left=[165,y];right=[178.2-i,108.5]
 v={'name':name+' bus east transition','net':r['net'],'at':right};err=p.add_via(v);print(v,err);s['vias'].append(v)
 buses.append({'name':name+' transverse bus','net':r['net'],'width':.15,'through':[left,[173,y],right],'layer':'F.Cu'})
 l=copy.deepcopy(r);l.update(name=name+' west lead',through=[r['through'][0],left],end_layer='F.Cu');connections.append(l)
 q=copy.deepcopy(r);q.update(name=name+' east lead',through=[right,r['through'][1]],start_layer='B.Cu',end_layer='B.Cu');connections.append(q)
 s['paths'].remove(r)
# These five crossovers have physical coordinates, not a broad exclusion strip.
front=[];trunks=[];back=[]
for r in s['paths']:
 if 'escape' in r['name'] or 'trunk access' in r['name'] or len(r.get('layers',[r.get('layer','F.Cu')]))==1:front.append(r)
 elif r['name'] in ['U1.36 to J2.13','U1.37 to J2.14','U1.38 to J2.12','U1.39 to J2.11','U1.41 to J2.10','U1.24 to J2.9']:trunks.append(r)
 else:back.append(r)
s['paths']=buses+front+trunks+connections+back
s['description']='Phase3 physical F.Cu charger control crossovers with B.Cu display trunks and SWD front-side southwest escapes'
s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/wholeboard-bus-apply.json'
(b/'wholeboard-bus-spec.json').write_text(json.dumps(s,indent=2)+'\n')
