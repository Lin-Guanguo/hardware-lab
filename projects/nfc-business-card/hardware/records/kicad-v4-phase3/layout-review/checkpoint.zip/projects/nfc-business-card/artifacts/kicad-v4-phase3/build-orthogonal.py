import sys,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,children,child,prop
p=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((p/'wholeboard-debug-bridge-spec.json').read_text());b=read(s['model_board']);fp=next(f for f in children(b,'footprint') if prop(f,'Reference')[2]=='R13');child(fp,'at')[:]=['at','177.1','96.6','0'];s['model_board']='projects/nfc-business-card/artifacts/kicad-v4-phase3/layout-orthogonal.kicad_pcb';write(s['model_board'],b);s['placements']['R13']=[177.1,96.6,0]
screens=['EPD_MOSI_TBD','EPD_SCK_TBD','EPD_CS_N_TBD','EPD_DC_TBD','EPD_RESET_N_TBD','EPD_BUSY_TBD']
s['reserved_corridors']=[{'layer':'B.Cu','bounds':[165.3,99.7,168,111.3],'nets':screens}]
oldscreen=[q for q in s['paths'] if q['net'] in screens and q['name'].startswith('U1.') and ' to J2.' in q['name']]
fixed=[];main=[]
for q in s['paths']:
 if q in oldscreen:continue
 if q['name']=='C6.1 to C5.1' or main:main.append(q)
 else:fixed.append(q)
# The same-pad switch pairs must be complete before their module corridors.
pairs=[q for q in main if q['name'].startswith('SW')];main=[q for q in main if q not in pairs]
# Keep local escape geometry and the transverse/USB bridge portions first.
leads=[q for q in fixed if ' bridge source' in q['name'] or ' bridge destination' in q['name'] or 'bank source' in q['name'] or 'bank destination' in q['name']]
fixed=[q for q in fixed if q not in leads]
requests=[]
for idx,net in enumerate(screens):
 q=next(x for x in oldscreen if x['net']==net);x=165.6+.36*idx
 for label,pts,layers in [('south',[q['through'][0],[x,111.1]],['F.Cu','B.Cu']),('channel',[[x,111.1],[x,99.9]],['B.Cu']),('north',[[x,99.9],q['through'][-1]],['F.Cu','B.Cu'])]:
  requests.append({'name':q['name']+' '+label,'net':net,'width':.15,'through':pts,'layers':layers,'start_layer':'B.Cu','end_layer':'B.Cu','bounds':[160,93,177,120],'via_cost':10})
s['paths']=pairs+fixed+requests+leads+main
s['description']='Orthogonal joint channel: six bottom screen lanes cross five front charger lines; USB-side debug bridge'
s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/orthogonal-apply.json'
(p/'wholeboard-orthogonal-spec.json').write_text(json.dumps(s,indent=2)+'\n')
print(len(fixed),len(requests),len(leads),len(main))
