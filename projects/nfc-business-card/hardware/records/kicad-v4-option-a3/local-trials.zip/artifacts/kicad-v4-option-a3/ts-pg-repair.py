import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,child
from v4_geometry import geometry
from shapely.geometry import LineString,Point
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
ids=['50f98cc2-3177-403d-9dc9-3644567261f5','ffb749a1-3c11-42f2-abf9-51fed37ddee2','444a88b5-71b6-437d-b666-492a6af87411']
b[:]=[x for x in b if not(isinstance(x,list) and x[0]=='segment' and child(x,'uuid')[1] in ids)]
model=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/ts-pg-model.kicad_pcb');write(model,b)
s=importlib.util.spec_from_file_location('rt','projects/nfc-business-card/scripts/route-v4-octilinear.py');rt=importlib.util.module_from_spec(s);s.loader.exec_module(rt);r=rt.Planner(model)
routes=[dict(name='PG north approach to local layer bridge',net='CHG_PG_N',layer='B.Cu',width=.15,points=[[177,105.5],[176.2,104.7],[172.8,104.7]]),dict(name='PG local bridge opens TS on bottom',net='CHG_PG_N',layer='F.Cu',width=.15,points=[[172.8,104.7],[172.8,106.1]]),dict(name='PG original MCU corridor retained',net='CHG_PG_N',layer='B.Cu',width=.15,points=[[172.8,106.1],[172.8,114.899]])]
fail=[]
for line in routes:
 shape=LineString(line['points']).buffer(.075)
 for o in r.objects:
  if o['net']!=line['net'] and line['layer'] in o['layers'] and o['shape'].distance(shape)<.2-1e-6:fail.append([line['name'],o['name'],o['net']])
 r.routes.append(line);r.objects.append(dict(name=line['name'],net=line['net'],layers=[line['layer']],shape=shape,kind='track',points=line['points']))
for point in [[172.8,104.7],[172.8,106.1]]:
 e=r.add_via(dict(name='PG local crossover',net='CHG_PG_N',at=point))
 if e:fail.append(e)
if not fail:
 e=r.route(dict(name='TS through opened PG crossing',net='BAT_NTC_TBD',width=.15,through=['U2.6','R19.1'],layers=['F.Cu','B.Cu'],bounds=[168,101,178,113],join_existing_copper=True))
 if e:fail.append(e)
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 open one defined TS crossing by relocating three PG segments to a short local layer bridge',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/ts-pg-ipc.json',remove_trial_ids=ids,routes=r.routes,vias=r.vias,failures=fail)
(p/'ts-pg-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('failures',fail)
