exec(open('projects/nfc-business-card/artifacts/kicad-v4-option-a3/cs-local.py').read().split('q=dict')[0])
w=json.load(open('projects/nfc-business-card/hardware/records/kicad-v4-option-a3/local-access.json'))['results'][4]
points=['J2.12']+[e['new_via_witness_mm'] for e in w['layer_transitions']]+['U1.38'];fail=[]
for i,pnt in enumerate(points[1:-1]):
 e=r.add_via(dict(name='CS continuous access witness '+str(i),net='EPD_CS_N_TBD',at=pnt))
 if e:fail.append(e)
for i,(start,end) in enumerate(zip(points,points[1:])):
 q=dict(name='CS continuous witness leg '+str(i),net='EPD_CS_N_TBD',width=.15,through=[start,end],layer='F.Cu' if i%2==0 else 'B.Cu',bounds=[151,88,174,122])
 e=r.route(q);print(i,e or 'routed',flush=True)
 if e:fail.append(e);break
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 independently derived continuous access witnesses for CS, no route-order scan',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/cs-witness-ipc.json',routes=r.routes,vias=r.vias,failures=fail)
(p/'cs-witness-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
