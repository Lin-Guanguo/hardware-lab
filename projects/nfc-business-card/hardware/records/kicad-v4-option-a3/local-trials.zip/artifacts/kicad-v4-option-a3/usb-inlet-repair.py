import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,children,child
from v4_geometry import geometry
from shapely.geometry import LineString,Point
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b,pads,objs,refs=geometry(p/'NFC-Card-V4.kicad_pcb')
ids=[o['name'] for o in objs if o['kind'] in ['track','via'] and o['net']=='USB_VBUS' and o['shape'].bounds[2]>181.3]
ids.append('e2edfb45-6d76-4668-a6e9-e8922b95cbab')
objs=[o for o in objs if o['name'] not in ids]
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ['segment','via'] and child(x,'uuid')[1] in ids)]
routes=[];vias=[]
def t(name,net,layer,pts,w=.35):routes.append(dict(name=name,net=net,layer=layer,width=w,points=[pads[x]['at'] if isinstance(x,str) else x for x in pts]))
def v(name,net,pt):vias.append(dict(name=name,net=net,at=pt))
t('Upper VBUS contact escape','USB_VBUS','F.Cu',['J1.B4A9',(185.2,101.6005),(185.2,100.6)],.25)
t('Lower VBUS contact escape','USB_VBUS','F.Cu',['J1.A4B9',(185,106.4005)],.25)
t('VBUS outside USB pair on back','USB_VBUS','B.Cu',[(185.2,100.6),(185.7,101.1),(185.7,105.7),(184.7,106.7),(183,106.7)])
t('Lower VBUS into rear spine','USB_VBUS','B.Cu',[(185,106.4005),(184.7005,106.7),(183,106.7)])
t('VBUS charger local arrival','USB_VBUS','F.Cu',[(183,106.7),(182,106.7),(181,107.7),(181,108.7),'C8.1'])
t('Charger and USB local return bridge','GND','F.Cu',['C2.2',(182.2,105.6),(182.5,105.9)],.25)
for name,net,pt in [('VBUS upper','USB_VBUS',(185.2,100.6)),('VBUS lower','USB_VBUS',(185,106.4005)),('VBUS charger','USB_VBUS',(183,106.7)),('C3 USB ground bridge','GND',(182.5,105.9))]:v(name,net,pt)
gen=[dict(name=r['name'],net=r['net'],layers=[r['layer']],shape=LineString(r['points']).buffer(r['width']/2),kind='track') for r in routes]+[dict(name=v['name'],net=v['net'],layers=['F.Cu','B.Cu'],shape=Point(v['at']).buffer(.3),kind='via') for v in vias]
fail=[]
for i,x in enumerate(gen):
 for y in objs+gen[:i]:
  if x['net']!=y['net'] and set(x['layers'])&set(y['layers']) and x['shape'].distance(y['shape'])<.2-1e-6:fail.append([x['name'],y['name'],y['net']])
for v in vias:
 for y in objs:
  if y['kind']=='pad' and len(y['layers'])==1 and y['shape'].distance(Point(v['at']))<.55-1e-6:fail.append([v['name'],'drill',y['name']])
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 jointly move USB VBUS fanout off the CC outlets while retaining local charger return',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/usb-inlet-ipc.json',remove_trial_ids=ids,routes=routes,vias=vias,failures=fail)
(p/'usb-inlet-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('Removed objects',len(ids),'conflicts',fail)
