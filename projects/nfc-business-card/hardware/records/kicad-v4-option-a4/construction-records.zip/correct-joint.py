import json,sys,copy
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import *
from v4_geometry import geometry
P=Path('projects/nfc-business-card');R=P/'hardware/records/kicad-v4-option-a4'
p=json.loads((R/'entry-plan.json').read_text());old=json.loads((R/'entry-ipc.json').read_text())
b,pads,obs,f=geometry(P/'hardware/kicad/v4-option-a3-local/NFC-Card-V4.kicad_pcb')
initial_removed=set(p['remove_trial_ids']);p['remove_trial_ids']=old['created_ids'];p['placements'].update({r:list(f[r]) for r in ['U3','C4','C5']})
p['description']='A4 one joint correction: separate front USB/power from back display bundle and retain original LDO decoupling geometry'
p['record']=str(R/'corrected-ipc.json')
correction_nets={'SYS','USB_VBUS','VDD_3V3','GND','USB_DP_CONN','USB_DM_CONN','EPD_RESE'}|{n for n in ['EPD_MOSI_TBD','EPD_SCK_TBD','EPD_CS_N_TBD','EPD_DC_TBD','EPD_RESET_N_TBD','EPD_BUSY_TBD']}
p['routes']=[x for x in p['routes'] if x['net'] not in correction_nets]
p['vias']=[x for x in p['vias'] if x['net'] not in correction_nets]
def l(n,ly,w,pts,name):p['routes'].append({'net':n,'layer':ly,'width':w,'points':pts,'name':name})
def v(n,at,name):p['vias'].append({'net':n,'at':at,'name':name})
def restore(x):
 if x['kind']=='track':
  s=next(s for s in children(b,'segment') if child(s,'uuid')[1]==x['name'])
  l(x['net'],x['layers'][0],float(child(s,'width')[1]),x['points'],'retained original LDO/pullup geometry')
 else:v(x['net'],x['at'],'retained original LDO return/rail transition')
# Remove the original 3V3 pullup branch into the now relocated charging resistors.
for x in obs:
 if x['kind'] not in ['track','via']:continue
 if x['net']=='VDD_3V3':
  xmin,ymin,xmax,ymax=x['shape'].bounds
  keep=(ymax>108 and xmax<172.2 and not (x['layers']==['B.Cu'])) or ymin<99 or (x['kind']=='via' and x['at']==(167.6,101.4)) or (xmax<168.4 and ymin>100 and ymax<109.7)
  if x['kind']=='track' and x['layers']==['B.Cu'] and ymax<99:keep=True
  if keep:restore(x)
  elif x['name'] not in initial_removed:p['remove_trial_ids'].append(x['name'])
 if x['net']=='GND' and x['name'] in initial_removed and x['shape'].bounds[2]<173.0:restore(x)
 if x['net']=='EPD_RESE':p['remove_trial_ids'].append(x['name'])
# Preserve the existing C6/C7 supply pads and their short MCU branches.
for x in obs:
 if x['kind']=='track' and x['net']=='VDD_3V3' and x['layers']==['F.Cu'] and x['shape'].bounds[0]>170 and x['shape'].bounds[2]<172.5 and x['shape'].bounds[1]>111 and x['shape'].bounds[3]<114.2:
  if not any(r['points']==x['points'] and r['net']==x['net'] for r in p['routes']):restore(x)
l('VDD_3V3','F.Cu',.4,[(167.6,101.4),(167.6,102.1),(180.4,102.1),(183.6,98.9),(183.6,97.4)],'display feed front crossover')
l('VDD_3V3','B.Cu',.25,[(167.6,101.4),(165.8,101.4),(165.2,102),(150.2,102),(150.2,109.2)],'charging pullup supply')
for y in [103.5,105.4,107.3,109.2]:
 l('VDD_3V3','F.Cu',.15,[(150.9465,y),(150.2,y)],'charging pullup pad');v('VDD_3V3',(150.2,y),'charging pullup transition')
l('VDD_3V3','F.Cu',.15,[(154.2465,104.9),(153.5,104.9)],'CE pullup supply');v('VDD_3V3',(153.5,104.9),'CE supply transition')
l('VDD_3V3','B.Cu',.15,[(153.5,104.9),(150.2,104.9)],'CE pullup branch')
l('SYS','F.Cu',.15,[(158.8,106.25),(158.8,105.7),(159.4,105.7),(160,106.3),(162.2,106.3),(162.2,105.3)],'U2 SYS to C2')
l('SYS','F.Cu',.5,[(162.2,105.3),(174.7,105.3),(174.7,107.7)],'C2 to retained C4 input')
l('SYS','F.Cu',.35,[(174.7,107.7),(174.7,108.2),(174.25,108.65),(171.7,108.65)],'C4 to U3 IN')
l('SYS','F.Cu',.25,[(171.7,108.65),(172.6,108.65),(172.6,106.75),(171.7,106.75)],'U3 enable')
# Return C8 on its ground side, rather than crossing its VBUS pad.
l('GND','F.Cu',.15,[(157.2,106.25),(157.2,107.3),(158,107.3)],'U2 GND to EP')
l('GND','F.Cu',.35,[(158,107.3),(155.9,107.3)],'U2 EP ground landing');v('GND',(155.9,107.3),'charger local ground')
for pad,end in [('C2.2',(160.8,104.4)),('C3.2',(156.2,102.8)),('C8.2',(163.3,107.4)),('R19.2',(153.8,109.6))]:
 # These pads use the relocated group's coordinates, not source locations.
 starts={'C2.2':(160.8,105.3),'C3.2':(157.2,102.8),'C8.2':(162.2,107.4),'R19.2':(154.6465,109.6)}
 l('GND','F.Cu',.35,[starts[pad],end],pad+' local return');v('GND',end,pad+' filled-ground transition')
# A front-layer USB pair crosses the back display bundle as a whole.
l('USB_DP_CONN','F.Cu',.15,[(180,103.45),(167,103.45),(166.4,102.85)],'USB DP front transverse')
l('USB_DM_CONN','F.Cu',.15,[(180,104.15),(166.8,104.15),(166.4,103.75)],'USB DM front transverse')
v('USB_DP_CONN',(166.4,102.85),'USB DP west transition');v('USB_DM_CONN',(166.4,103.75),'USB DM west transition')
l('USB_DP_CONN','B.Cu',.15,[(166.4,102.85),(164.7,104.55),(164.7,110.6)],'USB DP west approach')
l('USB_DM_CONN','B.Cu',.15,[(166.4,103.75),(165.5,104.65),(165.5,109.6),(166.5,110.6)],'USB DM west approach')
for n,x in [('USB_DP_CONN',164.7),('USB_DM_CONN',166.5)]:
 v(n,(x,110.6),'USB resistor transition');l(n,'F.Cu',.15,[(x,110.6),(x,111.7465)],'USB resistor input')
# VBUS branches leave the connector and turn to the back only west of the screen bundle.
l('USB_VBUS','F.Cu',.35,[(186.149,106.4005),(185.2,106.4005),(182.9005,108.7),(180.2,108.7),(180.2,105.8),(179,104.6),(167,104.6)],'VBUS front west trunk')
v('USB_VBUS',(167,104.6),'VBUS west transition')
l('USB_VBUS','B.Cu',.35,[(167,104.6),(162.5,104.6),(160.8,106.3),(160.8,106.4)],'VBUS west branch to C8');v('USB_VBUS',(160.8,106.4),'C8 input transition')
l('USB_VBUS','F.Cu',.35,[(160.8,106.4),(160.8,107.4)],'C8 input')
l('USB_VBUS','F.Cu',.15,[(160.8,107.4),(160.8,107.95),(159.6,109.15),(158.8,108.35)],'C8 to U2 IN')
l('USB_VBUS','F.Cu',.35,[(186.149,101.6005),(184.3,101.6005),(183.8,101.1005)],'upper VBUS contact');v('USB_VBUS',(183.8,101.1005),'upper VBUS transition')
l('USB_VBUS','B.Cu',.35,[(183.8,101.1005),(182.8,102.1005),(182.8,106.1),(181.8,107.1)],'VBUS contacts bridge');v('USB_VBUS',(181.8,107.1),'lower VBUS transition')
l('USB_VBUS','F.Cu',.35,[(181.8,107.1),(180.2,108.7)],'VBUS contacts closure')
l('USB_VBUS','B.Cu',.25,[(167,104.6),(167,109.6),(169.9,112.5)],'separate C1 branch');v('USB_VBUS',(169.9,112.5),'C1 transition')
l('USB_VBUS','F.Cu',.25,[(169.9,112.5),(169.801,112.401),(169.001,112.401),(168.8,112.2)],'C1 input')
l('USB_VBUS','F.Cu',.25,[(169.001,112.401),(169.001,113.934)],'C1 U1 VBUS stub')
# Fan-out spacing expands from 0.5 mm FPC pitch to 0.8 mm via pitch.
channels=[('EPD_MOSI_TBD',26,172.201),('EPD_SCK_TBD',24,173.001),('EPD_CS_N_TBD',22,173.801),('EPD_DC_TBD',20,174.601),('EPD_RESET_N_TBD',19,175.001),('EPD_BUSY_TBD',16,177.001)]
for i,(n,pin,x) in enumerate(channels):
 a=(x,116.1 if pin==19 else 112.5);sy=114.834 if pin==19 else 113.934
 l(n,'F.Cu',.15,[(x,sy),a],'MCU screen escape');v(n,a,'screen MCU transition')
 ey=round(93.99+i*.8,5);end=(168.2,ey);bend=(x,round(ey+x-168.2,5))
 l(n,'B.Cu',.15,[a,bend,end],'parallel screen corridor');v(n,end,'screen FPC transition')
 py=round(94.99+i*.5,5);corner=(round(168.2-abs(ey-py),5),py)
 l(n,'F.Cu',.15,[(166.325,py),corner,end],'expanded FPC fanout')
l('EPD_RESE','F.Cu',.2,[(173.6,99.35),(174.196,99.35),(175.046,100.2),(175.0465,100.2),(175.7565,100.2)],'Q1 R15 RESE local path')
l('EPD_RESE','F.Cu',.15,[(175.7565,100.2),(175.7565,101.2),(175.4565,101.5),(167.335,101.5),(166.325,100.49)],'RESE front return to FPC')
p['remove_trial_ids']=list(dict.fromkeys(p['remove_trial_ids']))
(R/'corrected-plan.json').write_text(json.dumps(p,indent=2)+'\n')
(R/'correction-rationale.json').write_text(json.dumps({'changed_conditions':['USB transverse F.Cu; display transverse B.Cu','FPC fanout expands from 0.5 to 0.8 mm via pitch','U3 C4 C5 returned as an intact group to A3 locations','3V3 display and RESE bridges change from B.Cu to F.Cu','C8 ground exits its GND side; not across its IN pad'],'not_proven':['charging control bus/pullup closure','USB CC closure','sampling BAT tap','same-board ground integrity','physical infeasibility of two layers']},indent=2)+'\n')
print('correction routes',len(p['routes']),'vias',len(p['vias']))
