import sys,json
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module();from shapely.geometry import Point
s=json.load(open('projects/nfc-business-card/hardware/kicad/v4-phase3/wholeboard-bus2-spec.json'));p=m.Planner(s['board'])
for v in s['vias']:p.add_via(v)
for r in s['paths'][:8]:
 print(r['name'],p.route(r))
 print([x for x in p.routes if x['name']==r['name']])
 if r['name']=='R8.2 to U1.20 transverse bus':
  for at in r['through']:
   print(at,[(o['name'],o['shape'].distance(Point(at)),o['shape'].bounds) for o in p.objects if o['net']!=r['net'] and 'F.Cu' in o['layers'] and o['shape'].distance(Point(at))<.3])
