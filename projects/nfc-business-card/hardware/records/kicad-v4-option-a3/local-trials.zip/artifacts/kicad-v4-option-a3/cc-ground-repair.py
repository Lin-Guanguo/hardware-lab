import sys,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,children,child,prop
from v4_geometry import geometry
from shapely.geometry import LineString
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
f=next(f for f in children(b,'footprint') if prop(f,'Reference')[2]=='R1');child(f,'at')[:]=['at','182.5','110.2','180']
for pad in children(f,'pad'):
 at=child(pad,'at');at[:]=at[:3]+[str(((float(at[3]) if len(at)>3 else 0)+180)%360)]
ids=[child(x,'uuid')[1] for x in children(b,'segment') if child(x,'net')[-1]=='USB_CC1']
b[:]=[x for x in b if not(isinstance(x,list) and x[0]=='segment' and child(x,'uuid')[1] in ids)]
q=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/cc-ground-model.kicad_pcb');write(q,b)
_,pads,objs,_=geometry(q)
route=dict(name='CC1 direct approach to rotated R1',net='USB_CC1',layer='F.Cu',width=.15,points=[pads['R1.1']['at'],[184.5,108.9535],pads['U6.1']['at']])
errors=[o['name'] for o in objs if o['net']!=route['net'] and 'F.Cu' in o['layers'] and o['shape'].distance(LineString(route['points']).buffer(.075))<.2-1e-6]
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 rotate R1 within its existing envelope so CC1 no longer wraps around its ground pad',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/cc-ground-ipc.json',placements={'R1':[182.5,110.2,180]},remove_trial_ids=ids,routes=[route],failures=errors)
(p/'cc-ground-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(plan,indent=2))
