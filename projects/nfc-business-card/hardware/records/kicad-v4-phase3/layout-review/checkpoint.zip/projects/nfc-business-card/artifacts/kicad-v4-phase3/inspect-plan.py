import sys,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from v4_geometry import geometry
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as Patch
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-reserved-spec.json').read_text());p=json.loads((b/'wholeboard-reserved-spec-plan.json').read_text());_,pads,objs,fps=geometry(s['board'])
for ref in ('U1','U5','U6','R3','R4','U3','C1','C4','C5','C6','C7'):
 print(ref,[(k,tuple(round(x,4) for x in v['at']),v['net']) for k,v in pads.items() if k.startswith(ref+'.')])
fig,axs=plt.subplots(1,2,figsize=(20,14))
for ax,layer in zip(axs,('F.Cu','B.Cu')):
 for o in objs:
  if layer not in o['layers']:continue
  g=o['shape']; geoms=g.geoms if hasattr(g,'geoms') else [g]
  for g in geoms:
   if hasattr(g,'exterior'):ax.add_patch(Patch(g.exterior.coords,facecolor='#bbbbbb',edgecolor='#777777',alpha=.6))
  if o['kind']=='pad':ax.text(*o['at'],o['name'],fontsize=4,ha='center')
 for r in p['routes']:
  if r['layer']==layer:
   x,y=zip(*r['points']);color=plt.cm.tab20(hash(r['net'])%20);ax.plot(x,y,lw=max(.5,r['width']*4),color=color)
 for v in p['vias']:ax.add_patch(plt.Circle(v['at'],.3,color=plt.cm.tab20(hash(v['net'])%20),fill=False))
 ax.set_xlim(151,190);ax.set_ylim(127,99);ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_title(layer)
fig.savefig('projects/nfc-business-card/artifacts/kicad-v4-phase3/planned-overview.png',dpi=160)
