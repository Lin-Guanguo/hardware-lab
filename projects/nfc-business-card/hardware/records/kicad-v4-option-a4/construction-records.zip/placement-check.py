import sys,copy,json,math
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import *
from shapely.geometry import box,Polygon
from shapely import affinity
root=Path('projects/nfc-business-card'); src=root/'hardware/kicad/v4-option-a3-local/NFC-Card-V4.kicad_pcb'; out=root/'artifacts/kicad-v4-option-a4'
placements={'U2':[158,107.3,180], 'C3':[157.2,103.5,90],'C2':[161.5,105.3,180],'C8':[161.5,107.4,0],'R19':[155.4,109.6,180],'NTC':[154,107.5,0],'R7':[155,104.9,0],'U3':[166.1,108.4,90],'C4':[169.5,108.4,180],'C5':[162.8,109.35,180],'R3':[164.7,112.5,270],'R4':[166.5,112.5,270],'R5':[151.7,103.5,0],'R6':[151.7,105.4,0],'R8':[151.7,107.3,0],'R9':[151.7,109.2,0]}
b=read(src); cs={}
for f in children(b,'footprint'):
 ref=prop(f,'Reference')[2]; at=child(f,'at'); old=float(at[3]) if len(at)>3 else 0
 if ref in placements:
  x,y,ang=placements[ref]; at[:]=['at',str(x),str(y),str(ang)]
  for p in children(f,'pad'):
   pa=child(p,'at'); pa[:]=pa[:3]+[str(((float(pa[3]) if len(pa)>3 else 0)+ang-old)%360)]
 x,y=map(float,at[1:3]);ang=float(at[3]) if len(at)>3 else 0
 for r in children(f,'fp_rect'):
  if child(r,'layer')[1]!='F.CrtYd':continue
  s,e=child(r,'start'),child(r,'end');cs[ref]=affinity.translate(affinity.rotate(box(*map(float,s[1:3]),*map(float,e[1:3])),-ang,origin=(0,0)),x,y)
for a,g in cs.items():
 for c,h in cs.items():
  if a<c and (a in placements or c in placements) and g.intersection(h).area>1e-8: print('OVERLAP',a,c,g.intersection(h).area)
print('PLACEMENTS',json.dumps(placements))
# A placement-only diagnostic has no routing or fill; it is not a candidate pass.
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ('segment','via'))]
for z in children(b,'zone'):remove(z,'filled_polygon')
write(out/'west-placement.kicad_pcb',b)
(out/'placements.json').write_text(json.dumps(placements,indent=2)+'\n')
