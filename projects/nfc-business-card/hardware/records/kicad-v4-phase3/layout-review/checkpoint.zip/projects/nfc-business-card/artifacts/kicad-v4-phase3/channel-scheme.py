import json,sys
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from importlib.machinery import SourceFileLoader
m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-reserved-spec.json').read_text());s.pop('reserved_corridors',None)
p=m.Planner(s['board'])
for name,at in [('U5.1',[178.9,103.0]),('U5.2',[178.9,104.6])]:
 v={'name':name+' trunk access','net':p.pads[name]['net'],'at':at};print(v,p.add_via(v));s['vias'].append(v)
 for r in s['paths']:
  if r['name'] in ['R3.1 to U5.1','R4.1 to U5.2'] and r['through'][-1]==name:r['through'][-1]=at;r['end_layer']='B.Cu'
 s['paths'].insert(0,{'name':name+' trunk access','net':v['net'],'width':.15,'through':[name,at],'layer':'F.Cu'})
# Put all fine-pitch breakouts and local closed loops first, followed by horizontal
# service crossings. The screen/SWD bundle is allocated after these crossings.
front=[];middle=[];back=[]
for r in s['paths']:
 name=r['name']
 if any(k in name for k in ['escape','trunk access']) or 'layers' not in r or len(r['layers'])==1:front.append(r)
 elif name in ['C6.1 to C5.1','R3.1 to U5.1','R4.1 to U5.2'] or (name.startswith(('R5.2','R6.2','R7.2','R8.2','R9.2')) and 'U1' in name):middle.append(r)
 else:back.append(r)
s['paths']=front+middle+back
s['description']='Phase3 joint corridor candidate: pre-reserved USB ESD escapes and horizontal charger/MCU crossings before display trunks'
s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/wholeboard-crossing-apply.json'
(b/'wholeboard-crossing-spec.json').write_text(json.dumps(s,indent=2)+'\n')
