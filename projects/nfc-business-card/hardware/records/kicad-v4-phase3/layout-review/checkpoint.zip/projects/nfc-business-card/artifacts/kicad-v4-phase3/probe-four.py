import sys,json,importlib.util,copy
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
m=importlib.util.spec_from_file_location('router','projects/nfc-business-card/scripts/route-v4-octilinear.py');r=importlib.util.module_from_spec(m);m.loader.exec_module(r)
from shapely.geometry import Point,LineString
base=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((base/'wholeboard-open-crossing-spec.json').read_text());p=json.loads((base/'wholeboard-open-crossing-spec-plan.json').read_text())
fixed={q['name'] for q in s['paths'][:102]}
planner=r.Planner(s['model_board'])
assigned={tuple(v['at']) for v in s['vias']}
for v in p['vias']:
 ob={'name':v.get('name','generated via'),'net':v['net'],'layers':['F.Cu','B.Cu'],'shape':Point(v['at']).buffer(.3),'kind':'via','at':v['at']}
 if tuple(v['at']) in assigned:planner.objects.append(ob)
 else:planner.soft_obstacles.append(dict(ob,cost=100))
for q in p['routes']:
 ob={'name':q['name'],'net':q['net'],'layers':[q['layer']],'shape':LineString(q['points']).buffer(q['width']/2),'kind':'track','points':q['points']}
 if q['name'] in fixed:planner.objects.append(ob)
 else:planner.soft_obstacles.append(dict(ob,cost=100))
result=[]
for fail in p['failures']:
 req=next(q for q in s['paths'] if q['name']==fail['name']);probe=copy.deepcopy(planner);before=len(probe.objects);err=probe.route(req)
 conflicts={o['name'] for o in planner.soft_obstacles for q in probe.objects[before:] if o['net']!=q['net'] and set(o['layers'])&set(q['layers']) and o['shape'].distance(q['shape'])<.2}
 item={'name':req['name'],'failure':err,'conflicts':sorted(conflicts),'routes':probe.routes,'vias':probe.vias};result.append(item);print(json.dumps(item),flush=True)
Path('projects/nfc-business-card/artifacts/kicad-v4-phase3/probe-four.json').write_text(json.dumps(result,indent=2))
