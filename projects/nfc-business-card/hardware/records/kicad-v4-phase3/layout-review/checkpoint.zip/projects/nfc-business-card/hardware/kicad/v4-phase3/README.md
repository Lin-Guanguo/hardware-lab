# NFC V4 本轮完整候选

## 当前确定方案

2026-09-29，本目录是从 [第二阶段](../v4-phase2/README.md)独立复制的本轮候选，正在完成整板联合重排与布线，**尚未完成验收，不可投厂**。打开 [NFC-Card-V4.kicad_pro](NFC-Card-V4.kicad_pro)。双层 0.8 mm、机械／天线基准和电池采样保留，前版文件冻结指纹见 [记录](../../records/kicad-v4-phase3/phase2-baseline.json)。

本轮授权普通走线采用水平／垂直／45°、精简无用丝印。原始 NFC 铜线不作角度归一化；封装铜、阻焊、锡膏、courtyard 和板框不因丝印整理删除。

## 正在核查的候选

USB R3/R4 回靠 MCU 左侧；U3/C4/C5 作为一组移向西侧充电区，释放东北入口；C3 与按键上拉组按完整引脚出口重排。器件关系依据 [设计输入](../../v4-design-inputs.md)和 [pcb-methodology](../../../../../.agents/skills/pcb-methodology/SKILL.md)。

`*-spec.json` 和 `*-plan.json` 为不同阶段、方案或被拒绝的搜索结果，**不是顺序执行清单**。任何含 `failures` 的计划禁止写入。早期搜索没有正确复用已分配镀铜过孔的跨层连通，相关失败不能当成物理不可布的证明；`route-v4-octilinear.py` 已修正，结果仍须原生 DRC 与独立实铜检查确认。

## 电气与制造边界

[本轮具体换料建议与制造问题分类](../../v4-phase3-decisions.md)。C3 换料正在等用户决定；C1、VBUS 保护、屏幕峰值与电池电流的条件不能通过清除 DRC 代替。最终 Gerber/BOM/CPL/装配图及本轮 PCB/SMT DFM 尚未生成，不能借用前版报告。
