exec(open('projects/nfc-business-card/artifacts/kicad-v4-option-a3/stitch-windows.py').read().split('for i in range(1,len(groups)):')[0])
from shapely.geometry import LineString
points=[('C3-U5 return bridge',(181.2,106.65)),('MCU pin15 local return',(178.69,113.04)),('USB lower shell CC return',(185.50,113.48)),('MCU south/east return',(184.12,119.44)),('Keys and NFC matching return',(161.41,120.36)),('SW3 upper ground return',(153.82,114.91)),('CC2 resistor return',(182.55,112.80)),('J2 pin17 local return',(167.49,93.35))]
new=[];routes=[];errors=[]
for name,point in points:
 if not allowed.covers(Point(point)):errors.append((name,'clearance'))
 fids=[i for i in cu if cu[i]['F.Cu'].covers(Point(point))];bids=[i for i in cu if cu[i]['B.Cu'].covers(Point(point))]
 if not fids or not bids:errors.append((name,'missing surface contact',fids,bids))
 new.append(dict(name=name,net='GND',at=point,before_surface_groups={'F.Cu':fids,'B.Cu':bids}))
# Isolated resistor/capacitor pads need a trace into the ground on the other face.
barrier=unary_union([o['shape'].buffer(.325) for o in objects if o['net']!='GND' and 'F.Cu' in o['layers']])
for name in ['C25.1','R1.2']:
 source=Point(pads[name]['at'])
 space=allowed.intersection(planes['B.Cu']).intersection(source.buffer(2.5))
 pieces=list(space.geoms) if hasattr(space,'geoms') else [space]
 witnesses=[]
 for g in pieces:
  g=g.buffer(-.02)
  if g.is_empty:continue
  q=nearest_points(source,g)[1]
  for pt in [q,g.representative_point()]:
   point=tuple(round(v,5) for v in pt.coords[0])
   for line in rt.bends(pads[name]['at'],point):
    if not barrier.intersects(LineString(line)):
     witnesses.append((LineString(line).length,point,line))
 if not witnesses:errors.append((name,'no direct local witness'));continue
 _,point,line=min(witnesses)
 new.append(dict(name=name+' return via',net='GND',at=point))
 routes.append(dict(name=name+' ground stub',net='GND',layer='F.Cu',width=.25,points=rt.simplify(line)))
plan=dict(board=str(p),description='A3 restore identified loaded ground components through checked two-face copper contacts',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/ground-batch-ipc.json',routes=routes,vias=new,failures=errors)
Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local/ground-batch-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan,indent=2))
