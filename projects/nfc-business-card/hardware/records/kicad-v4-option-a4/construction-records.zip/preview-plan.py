import sys,json,copy,uuid,math
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import *
from v4_geometry import geometry
from shapely.strtree import STRtree
P=Path('projects/nfc-business-card');R=P/'hardware/records/kicad-v4-option-a4';A=P/'artifacts/kicad-v4-option-a4'
p=json.loads((R/'entry-plan.json').read_text());b=read(P/'hardware/kicad/v4-option-a4-joint/NFC-Card-V4.kicad_pcb')
for f in children(b,'footprint'):
 ref=prop(f,'Reference')[2]
 if ref in p['placements']:
  at=child(f,'at');old=float(at[3]) if len(at)>3 else 0;x,y,a=p['placements'][ref];at[:]=['at',str(x),str(y),str(a)]
  for pad in children(f,'pad'):
   at=child(pad,'at');at[:]=at[:3]+[str(((float(at[3]) if len(at)>3 else 0)+a-old)%360)]
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ('segment','via') and child(x,'uuid')[1] in p['remove_trial_ids'])]
newnames={}
for r in p['routes']:
 for a,c in zip(r['points'],r['points'][1:]):
  uid=str(uuid.uuid4());newnames[uid]=r['name']
  b.append(['segment',['start',*map(str,a)],['end',*map(str,c)],['width',str(r['width'])],['layer',Quoted(r['layer'])],['net',Quoted(r['net'])],['uuid',Quoted(uid)]])
for v in p['vias']:
 uid=str(uuid.uuid4());newnames[uid]=v['name']
 b.append(['via',['at',*map(str,v['at'])],['size','.6'],['drill','.3'],['layers',Quoted('F.Cu'),Quoted('B.Cu')],['net',Quoted(v['net'])],['uuid',Quoted(uid)]])
for z in children(b,'zone'):remove(z,'filled_polygon')
write(A/'entry-preview.kicad_pcb',b)
b,pa,objs,f=geometry(A/'entry-preview.kicad_pcb');tree=STRtree([o['shape'] for o in objs]);conf=[]
for i,o in enumerate(objs):
 for j in tree.query(o['shape'].buffer(.2)):
  if j<=i:continue
  q=objs[j]
  if not(o['name'] in newnames or q['name'] in newnames):continue
  if o['net']==q['net'] or not set(o['layers'])&set(q['layers']):continue
  d=o['shape'].distance(q['shape'])
  if d<.1999:
   conf.append({'a':newnames.get(o['name'],o['name']),'an':o['net'],'b':newnames.get(q['name'],q['name']),'bn':q['net'],'distance':round(d,4),'layer':sorted(set(o['layers'])&set(q['layers'])),'xy':list(o['shape'].intersection(q['shape'].buffer(.2)).representative_point().coords)[0]})
(R/'preview-collisions.json').write_text(json.dumps(conf,indent=2)+'\n')
from collections import Counter
print('conflicts',len(conf));print(Counter((x['an'],x['bn']) for x in conf))
for x in conf:print(x)
