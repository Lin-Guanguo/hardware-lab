exec(open('projects/nfc-business-card/artifacts/kicad-v4-option-a3/stitch-windows.py').read().split('for i in range(1,len(groups)):')[0])
for label,window,start,end in [('Display to LDO',(165,94,185.1,110.5),'U3.2','C9.2'),('MCU return',(164.5,108.5,179.3,115.2),'C7.2','U1.15')]:
 _,pd,ob,rf,pl,nd,gs,pg=m.inspect(p,window)
 print(label,'source',pg[start],'target',pg[end])
 if pg[start]==pg[end]:continue
 localcu={i:{l:unary_union([nd[k] for k in g if k[0]==l]) for l in planes} for i,g in enumerate(gs)}
 i,j=pg[start][0],pg[end][0]
 space=unary_union([localcu[i]['F.Cu'].intersection(localcu[j]['B.Cu']),localcu[i]['B.Cu'].intersection(localcu[j]['F.Cu'])]).buffer(-.02).intersection(allowed).buffer(-.01)
 print('direct bridge area',space.area,'bounds',space.bounds)
 if not space.is_empty:
  q=nearest_points(Point(pd[start]['at']),space)[1];print('witness',list(q.coords[0]))
