import json,sys,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,child,children,prop
f=importlib.util.spec_from_file_location('r','projects/nfc-business-card/scripts/route-v4-octilinear.py');m=importlib.util.module_from_spec(f);f.loader.exec_module(m)
p=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((p/'wholeboard-control-bank-spec.json').read_text());s['model_board']='projects/nfc-business-card/artifacts/kicad-v4-phase3/layout-debug-bridge.kicad_pcb';b=read(s['model_board']);fp=next(f for f in children(b,'footprint') if prop(f,'Reference')[2]=='R13');child(fp,'at')[:]=['at','177.1','97.4','0'];write(s['model_board'],b)
s['placements']={'C2':[162.2,105.2,0],'C9':[181.8,97.8,0],'R13':[177.1,97.4,0]}
s['paths']=[x for x in s['paths'] if x['name'] not in ('U1.53 to TP3.1','U1.51 to TP4.1','U1.40 to TP5.1')]
changes=[([179.7,98.5],[179.3,98.7]),([171.2,116.7],[171.2,116.9]),([172.3,117.5],[172.3,118.1]),([172.3,116.5],[172.4,116.5])]
for old,new in changes:
 for v in s['vias']:
  if v['at']==old:v['at']=new
 for req in s['paths']:req['through']=[new if x==old else x for x in req['through']]
bridges=[];leads=[]
items=[('SWDCLK',[165.9,118.7],[[180.8,105.5],[181.8,104.5],[181.8,102.3],[181.5,102]],'TP3.1'),('SWDIO',[167.2,118.95],[[182.8,106.8],[182.3,106.3],[182.3,100.8]],'TP4.1'),('NRESET',[172.3,118.1],[[184.8,108.6],[185.1,108.3],[185.1,107.5],[184.6,107],[183.9,107],[182.7,105.8],[182.7,101.9],[183.4,101.2]],'TP5.1')]
for net,src,points,end in items:
 for label,at in [('south',points[0]),('north',points[-1])]:s['vias'].append({'name':net+' USB-side bridge '+label,'net':net,'at':at})
 bridges.append({'name':net+' USB-side front bridge','net':net,'width':.15,'through':points,'layer':'F.Cu','bounds':[179,100,186,108]})
 for label,pts in [('source',[src,points[0]]),('destination',[points[-1],end])]:leads.append({'name':net+' bridge '+label,'net':net,'width':.15,'through':pts,'layers':['F.Cu','B.Cu'],'start_layer':'B.Cu','end_layer':'B.Cu','bounds':[162,80,191,124],'via_cost':6,'join_existing_copper':True})
for pin,at in [('J1.A4B9',[185,106.35]),('J1.B4A9',[184.8,100.9])]:
 s['vias'].append({'name':pin+' VBUS access','net':'USB_VBUS','at':at})
 bridges.append({'name':pin+' VBUS access','net':'USB_VBUS','width':.35,'through':[pin,at],'layer':'F.Cu'})
s['paths']=bridges+s['paths']
keys=[x for x in s['paths'] if 'module traverse' in x['name']];s['paths']=[x for x in s['paths'] if x not in keys]
i=next(i for i,x in enumerate(s['paths']) if 'front bank crossing' in x['name']);s['paths'][i:i]=keys
i=next(i for i,x in enumerate(s['paths']) if x['name']=='C6.1 to C5.1');s['paths'][i:i]=leads
pl=m.Planner(s['model_board']);errors=[]
for v in s['vias']:
 result=pl.add_via(v)
 if result:errors.append(result)
print(errors);assert not errors
(p/'wholeboard-debug-bridge-spec.json').write_text(json.dumps(s,indent=2)+'\n')
