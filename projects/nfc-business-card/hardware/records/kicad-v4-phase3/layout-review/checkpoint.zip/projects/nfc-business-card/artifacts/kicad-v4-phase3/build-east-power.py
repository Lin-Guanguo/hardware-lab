import json,sys
from pathlib import Path
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-east-spec.json').read_text());p=m.Planner(s['board'])
s['vias']=[v for v in s['vias'] if v['name']!='C5.2 ground return'];changed={}
move={'U1.3 service escape':[171.2,123.5],'U1.4 service escape':[170.5,122.5],'U1.5 service escape':[170.5,121.5]}
for v in s['vias']:
 if v['name'] in move:changed[tuple(v['at'])]=move[v['name']];v['at']=move[v['name']]
for r in s['paths']:
 r['through']=[changed.get(tuple(x),x) if isinstance(x,list) else x for x in r['through']]
 if r['name']=='C5.2 ground return':r['through']=['C5.2','U3.2']
front=[];power=[];back=[]
for r in s['paths']:
 if 'escape' in r['name'] or 'access' in r['name'] or 'transverse bus' in r['name'] or len(r.get('layers',[r.get('layer','F.Cu')]))==1:front.append(r)
 elif r['net'] in ['VDD_3V3','USB_VBUS','SYS','BAT_PACK_TBD']:power.append(r)
 else:back.append(r)
s['paths']=front+power+back
for v in s['vias']:
 error=p.add_via(v)
 if error:print(error);raise SystemExit('Invalid via')
s['description']='Northeast regulator variant with local C5 loop, west-facing key pin escapes, and power trunks planned before long signals';s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/wholeboard-east-power-apply.json';(b/'wholeboard-east-power-spec.json').write_text(json.dumps(s,indent=2)+'\n')
