import sys,json
from pathlib import Path
from shapely.geometry import Point,LineString
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts')
m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');spec=json.loads((b/'wholeboard-reserved-spec.json').read_text());plan=json.loads((b/'wholeboard-reserved-spec-plan.json').read_text())
p=m.Planner(spec['board'])
for v in plan['vias']:p.objects.append({'name':'planned via','net':v['net'],'kind':'via','layers':['F.Cu','B.Cu'],'shape':Point(v['at']).buffer(.3),'at':v['at']})
for r in plan['routes']:p.objects.append({'name':r['name'],'net':r['net'],'kind':'track','layers':[r['layer']],'shape':LineString(r['points']).buffer(r['width']/2)})
for name in ['R8.2 to U1.20','U1.3 to SW1.2','R3.1 to U5.1']:
 r=next(r for r in spec['paths'] if r['name']==name);result=p.route(r);print(json.dumps({'name':name,'result':result,'new_routes':p.routes},indent=2),flush=True)
