import sys,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,child,children,prop
from v4_geometry import geometry
from shapely.geometry import LineString,Point
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
placements={'R19':[175.35,110.9,90],'NTC':[174.5,104.75,0]}
for f in children(b,'footprint'):
 ref=prop(f,'Reference')[2]
 if ref not in placements:continue
 at=child(f,'at');delta=placements[ref][2]-(float(at[3]) if len(at)>3 else 0);at[:]=['at',*map(str,placements[ref])]
 for pad in children(f,'pad'):
  pa=child(pad,'at');pa[:]=pa[:3]+[str(((float(pa[3]) if len(pa)>3 else 0)+delta)%360)]
ids=['2c8b0f57-6796-4c86-9c90-8edfc483550e','63c470ba-1454-4c9b-931f-61dfa0aaa3fe','8099451a-f300-4b5a-9e15-72ab5beeb6c6']
ids += [child(x,'uuid')[1] for x in children(b,'segment') if child(x,'net')[-1]=='BAT_NTC_TBD']
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ['segment','via'] and child(x,'uuid')[1] in ids)]
model=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/ts-group-model.kicad_pcb');write(model,b)
_,pads,objs,refs=geometry(model)
routes=[dict(name='TS local resistor on charger side',net='BAT_NTC_TBD',layer='F.Cu',width=.15,points=[pads['U2.6']['at'],[176.2,111.4],[175.9465,111.6535],pads['R19.1']['at']]),dict(name='NTC reserve to charger direct corridor',net='BAT_NTC_TBD',layer='F.Cu',width=.15,points=[pads['NTC.1']['at'],[175.4,105.65],[175.4,108.25],pads['U2.6']['at']]),dict(name='R19 local return',net='GND',layer='F.Cu',width=.25,points=[pads['R19.2']['at'],[175.35,110.1035],[174.5465,109.3]])]
vias=[dict(name='R19 local ground return',net='GND',at=[174.5465,109.3])]
gen=[dict(name=r['name'],net=r['net'],layers=[r['layer']],shape=LineString(r['points']).buffer(r['width']/2),kind='track') for r in routes]+[dict(name=v['name'],net=v['net'],layers=['F.Cu','B.Cu'],shape=Point(v['at']).buffer(.3),kind='via') for v in vias]
fail=[]
for i,x in enumerate(gen):
 for y in objs+gen[:i]:
  if x['net']!=y['net'] and set(x['layers'])&set(y['layers']) and x['shape'].distance(y['shape'])<.2-1e-6:fail.append([x['name'],y['name'],y['net']])
for v in vias:
 for y in objs:
  if y['kind']=='pad' and len(y['layers'])==1 and y['shape'].distance(Point(v['at']))<.55-1e-6:fail.append([v['name'],'drill',y['name']])
for x in [o for o in objs if o['kind']=='pad' and o['name'].split('.')[0] in placements]:
 for y in objs:
  if x['net']!=y['net'] and y['name']!=x['name'] and set(x['layers'])&set(y['layers']) and x['shape'].distance(y['shape'])<.2-1e-6:fail.append([x['name'],y['name'],y['net']])
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 move TS resistor and NTC reserve to the charger side of PG, retaining the existing PG and supply returns',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/ts-group-ipc.json',placements=placements,remove_trial_ids=ids,routes=routes,vias=vias,failures=fail)
(p/'ts-group-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('conflicts',fail)
