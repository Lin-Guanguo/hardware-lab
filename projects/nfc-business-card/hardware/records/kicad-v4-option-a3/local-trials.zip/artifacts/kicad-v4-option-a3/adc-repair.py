import sys,importlib.util,json,copy
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,child,write
from shapely.geometry import LineString,Point,box
from shapely.ops import unary_union,nearest_points
spec=importlib.util.spec_from_file_location('rt','projects/nfc-business-card/scripts/route-v4-octilinear.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local/NFC-Card-V4.kicad_pcb');b=read(p)
ids=['65051795-57c5-46a9-a23a-3f095abee5dc','767bc5de-abf4-4f45-a4c3-375b33d45a3c','c09a9dff-925f-4b52-84dc-a2eecd3185c0','15dd2318-7515-4b76-9832-0303ef973113','e4664e64-ca76-49b4-8072-27754b8756b5']
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ['segment','via'] and child(x,'uuid')[1] in ids)]
model=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/adc-local-model.kicad_pcb');write(model,b)
r=m.Planner(model)
failures=[]
req={'name':'ADC local reroute clear of filter ground','net':'BAT_ADC_SENSE','width':.15,'through':['C25.2',(183.3,119.4)],'layers':['F.Cu','B.Cu'],'bounds':[180.6,114.2,185,119.7],'join_existing_copper':False,'via_cost':6}
e=r.route(req)
if e:failures.append(e)
plan={'board':str(p),'description':'A3 reroute only ADC filter branch to release C25 ground','record':'projects/nfc-business-card/hardware/records/kicad-v4-option-a3/adc-repair-ipc.json','remove_trial_ids':ids,'routes':r.routes,'vias':r.vias,'failures':failures}
Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local/adc-repair-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan,indent=2))
