import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
s=importlib.util.spec_from_file_location('rt','projects/nfc-business-card/scripts/route-v4-octilinear.py');rt=importlib.util.module_from_spec(s);s.loader.exec_module(rt)
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');r=rt.Planner(p/'NFC-Card-V4.kicad_pcb')
q=dict(name='CS local corridor check with all supply returns present',net='EPD_CS_N_TBD',width=.15,through=['U1.38','J2.12'],layers=['F.Cu','B.Cu'],bounds=[152,88,174,120],join_existing_copper=True)
e=r.route(q)
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 bounded CS route only',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/cs-local-ipc.json',routes=r.routes,vias=r.vias,failures=[e] if e else [])
(p/'cs-local-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(e or 'routed')
