import sys,json
from pathlib import Path
from importlib.machinery import SourceFileLoader
sys.path.insert(0,'projects/nfc-business-card/scripts');m=SourceFileLoader('octi','projects/nfc-business-card/scripts/route-v4-octilinear.py').load_module()
b=Path('projects/nfc-business-card/hardware/kicad/v4-phase3');s=json.loads((b/'wholeboard-junctions-spec.json').read_text());p=m.Planner(s['board'])
for v in s['vias']:
 if v['net']=='EPD_EN_TBD' and v['at']==[172.1,116.7]:v['at']=[171.8,115.8]
for r in s['paths']:
 if r['net']=='EPD_EN_TBD':r['through']=[[171.8,115.8] if x==[172.1,116.7] else x for x in r['through']]
for v in s['vias']:
 error=p.add_via(v)
 if error:print(error)
front=[]
for pin,at,width in [('U1.11',[175.8,118.534],.15),('C1.1',[167.7,112.2],.3),('C8.1',[162.8,110.3],.3),('C3.1',[161.3,104.4],.3)]:
 v={'name':pin+' planned supply/sense access','net':p.pads[pin]['net'],'at':at};error=p.add_via(v);print(v,error)
 if error:raise SystemExit('Invalid access')
 s['vias'].append(v);front.append({'name':pin+' planned supply/sense access','net':v['net'],'width':width,'through':[pin,at],'layer':'F.Cu'})
 for r in s['paths']:
  if r['name']=='U1.11 to C25.2':r['through'][0]=[175.8,118.534];r['start_layer']='B.Cu'
for r in s['paths']:
 if r['net']=='SYS' and len(r['through'])==2 and len(r.get('layers',[]))==2:r['join_existing_copper']=True
# Keep the load-switch command with the already reserved display bundle.
early=[r for r in s['paths'] if r['name'] in ['U1.27 to R13.1','R13.1 to U4.3']]
s['paths']=front+[r for r in s['paths'] if r not in early]
i=next(i for i,r in enumerate(s['paths']) if r['name']=='U1.39 to J2.11');s['paths'][i:i]=early
s['description']='Complete supply, ADC and enable access planned with the shared MCU/display/key corridor'
s['record']='projects/nfc-business-card/hardware/records/kicad-v4-phase3/wholeboard-access-apply.json';(b/'wholeboard-access-spec.json').write_text(json.dumps(s,indent=2)+'\n')
