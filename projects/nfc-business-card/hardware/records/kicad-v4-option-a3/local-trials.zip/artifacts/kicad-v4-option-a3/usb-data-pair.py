import sys,json,importlib.util
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,child,children
from v4_geometry import geometry
from shapely.geometry import LineString
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
oldplan=json.load(open('projects/nfc-business-card/hardware/kicad/v4-option-a2-full/successful-batch-plan.json'));oldids=json.load(open('projects/nfc-business-card/hardware/records/kicad-v4-option-a2/full-successful-batch-ipc.json'))['created_ids']
ids=[];i=0
for r in oldplan['routes']:
 n=len(r['points'])-1
 if r['name']=='USB DP':ids+=oldids[i:i+n]
 i+=n
for v in oldplan['vias']:
 if v['net']=='USB_DP_CONN':ids.append(oldids[i])
 i+=1
ids+=['ab1e49a8-6d80-4716-aa61-2d3c02847930']
b[:]=[x for x in b if not(isinstance(x,list) and x[0] in ['segment','via'] and child(x,'uuid')[1] in ids)]
model=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/usb-data-model.kicad_pcb');write(model,b)
s=importlib.util.spec_from_file_location('rt','projects/nfc-business-card/scripts/route-v4-octilinear.py');rt=importlib.util.module_from_spec(s);s.loader.exec_module(rt)
r=rt.Planner(model)
rail=dict(name='Display 3V3 crossing shifted north to allocate USB pair',net='VDD_3V3',layer='B.Cu',width=.35,points=[[167.6,101.4],[168,101],[179.2,101],[179.6,101.4]])
fail=[]
shape=LineString(rail['points']).buffer(.175)
for o in r.objects:
 if o['net']!=rail['net'] and 'B.Cu' in o['layers'] and o['shape'].distance(shape)<.2-1e-6:fail.append([rail['name'],o['name'],o['net']])
r.routes.append(rail);r.objects.append(dict(name=rail['name'],net=rail['net'],layers=['B.Cu'],shape=shape,kind='track',points=rail['points']))
if not fail:
 for net,start,end in [('USB_DM_CONN','U5.2','R4.1'),('USB_DP_CONN','U5.1','R3.1')]:
  e=r.route(dict(name=net+' joint local data pair',net=net,width=.15,through=[start,end],layers=['F.Cu','B.Cu'],bounds=[162.5,100.8,181.5,116.8],join_existing_copper=True))
  print(net,e or 'routed',flush=True)
  if e:fail.append(e)
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 jointly repair only USB data trunk and adjacent display-supply crossing',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/usb-data-pair-ipc.json',remove_trial_ids=ids,routes=r.routes,vias=r.vias,failures=fail)
(p/'usb-data-pair-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('failures',fail)
