import sys,json,copy,uuid
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import *
from v4_geometry import geometry
from shapely.geometry import box
P=Path('projects/nfc-business-card');R=P/'hardware/records/kicad-v4-option-a4';A=P/'artifacts/kicad-v4-option-a4';src=P/'hardware/kicad/v4-option-a3-local/NFC-Card-V4.kicad_pcb'
b,p,objects,f=geometry(src)
defn=json.loads((R/'joint-definition.json').read_text()); moves=defn['placements']
# Preserve the USB connector's data crossover; replace its long MCU branches later.
clear=set(defn['gpio'])|{'BAT_NTC_TBD','SYS','BAT_PACK_TBD','VDD_3V3','USB_VBUS','USB_DM_MCU','USB_DP_MCU'}
remove_ids=[x['name'] for x in objects if x['kind'] in ('track','via') and x['net'] in clear]
# Clear obsolete ground connections at moved power-group pads, keeping all other returns.
old_group=box(166,102.6,181,110.3)
remove_ids += [x['name'] for x in objects if x['kind'] in ('track','via') and x['net']=='GND' and old_group.covers(x['shape'])]
plan={'description':'A4 joint west power group and north display entry: explicit corridor witness, not autorouting',
 'board':str(P/'hardware/kicad/v4-option-a4-joint/NFC-Card-V4.kicad_pcb'),'record':str(R/'entry-ipc.json'),
 'placements':moves,'remove_trial_ids':remove_ids,'routes':[],'vias':[]}
def line(net,layer,w,pts,name):plan['routes'].append({'net':net,'layer':layer,'width':w,'points':pts,'name':name})
def via(net,at,name):plan['vias'].append({'net':net,'at':at,'name':name})
# Actual pad-to-pad power topology is defined first.
line('SYS','F.Cu',.15,[(158.8,106.25),(158.8,105.7),(159.4,105.7),(160,106.3),(162.2,106.3),(162.2,105.3)],'U2 SYS escape to C2')
line('SYS','F.Cu',.5,[(162.2,105.3),(170.2,105.3),(170.2,108.4)],'C2 to C4 input trunk')
line('SYS','F.Cu',.35,[(170.2,108.4),(170.2,109.35),(167.2,109.35)],'C4 to U3 IN')
line('SYS','F.Cu',.25,[(170.2,108.4),(170.2,107.45),(167.2,107.45)],'C4 to U3 EN')
line('BAT_PACK_TBD','F.Cu',.15,[(158.4,106.25),(158.4,104.6),(158,104.2),(157.2,104.2)],'U2 BAT to C3')
line('BAT_PACK_TBD','F.Cu',.5,[(142.5,111.3005),(144,109.8005),(151.5995,109.8005),(157.2,104.2)],'Battery positive to C3')
# The sampling tap is retained and explicitly reserved; it is not deleted from the net.
line('USB_VBUS','F.Cu',.15,[(158.8,108.35),(159.6,109.15),(160.8,107.95),(160.8,107.4)],'C8 to U2 IN')
line('USB_VBUS','F.Cu',.35,[(160.8,107.4),(160.8,108.3),(162,109.5),(162,110.7)],'C8 branch escape')
via('USB_VBUS',(162,110.7),'charger input transition')
line('USB_VBUS','B.Cu',.5,[(162,110.7),(162,111),(183.2,111),(184.5,109.7),(184.5,106.4005)],'VBUS west trunk')
via('USB_VBUS',(184.5,106.4005),'USB lower input transition')
line('USB_VBUS','F.Cu',.35,[(184.5,106.4005),(186.149,106.4005)],'USB lower input')
line('USB_VBUS','F.Cu',.35,[(186.149,101.6005),(184.3,101.6005),(183.8,101.1005)],'USB upper input away from CC2')
via('USB_VBUS',(183.8,101.1005),'USB upper input transition')
line('USB_VBUS','B.Cu',.5,[(183.8,101.1005),(182.8,102.1005),(182.8,104.7005),(184.5,106.4005)],'USB VBUS two contacts')
line('USB_VBUS','F.Cu',.25,[(168.8,112.2),(169.001,112.401),(169.001,113.934)],'C1 to U1 VBUS')
line('USB_VBUS','F.Cu',.25,[(168.8,112.2),(168.5,112.5),(168.5,112.8)],'C1 input transition stub')
via('USB_VBUS',(168.5,112.8),'C1 branch transition')
line('USB_VBUS','B.Cu',.35,[(168.5,112.8),(166.7,111),(162,111)],'C1 separate branch')
line('VDD_3V3','F.Cu',.5,[(163.5,109.35),(165,109.35),(165,110.25)],'U3 output and C5')
via('VDD_3V3',(165,110.25),'LDO output branch')
line('VDD_3V3','B.Cu',.4,[(165,110.25),(168.9,110.25),(169.6,109.55)],'MCU supply crossover under C1')
via('VDD_3V3',(169.6,109.55),'MCU supply entry')
line('VDD_3V3','F.Cu',.3,[(169.6,109.55),(169.6,110.55),(170.6,111.55),(172.1,111.55)],'C7 C6 shared local input')
line('VDD_3V3','F.Cu',.25,[(170.601,111.55),(170.601,113.934)],'C7 to VDDH')
line('VDD_3V3','F.Cu',.25,[(172.1,111.55),(171.401,112.249),(171.401,113.934)],'C6 to VDD')
line('VDD_3V3','F.Cu',.4,[(165,109.35),(165,110),(164.2,110.8),(161.7,110.8)],'LDO west supply branch')
via('VDD_3V3',(161.7,110.8),'pullup supply transition')
line('VDD_3V3','B.Cu',.35,[(161.7,110.8),(158.7,110.8),(156.7,112.8)],'key pullup supply')
via('VDD_3V3',(156.7,112.8),'key rail transition')
line('VDD_3V3','F.Cu',.2,[(156.7,112.8),(156.7,115.0535),(156.7,115.8),(157.1535,116.2535),(159,116.2535),(160,116.2535),(161,115.2535)],'key pullups')
line('VDD_3V3','B.Cu',.25,[(158.7,110.8),(153.1535,110.8),(150.9465,108.593),(150.9465,103.5)],'charger pullup supply')
for y in [103.5,105.4,107.3,109.2]:
 line('VDD_3V3','F.Cu',.15,[(150.9465,y),(150.2,y)],'charger pullup pad')
 via('VDD_3V3',(150.2,y),'charger pullup transition')
line('VDD_3V3','B.Cu',.25,[(150.2,103.5),(150.2,109.2),(150.9465,109.2),(150.9465,108.593)],'pullup via bus')
line('VDD_3V3','F.Cu',.2,[(154.2465,104.9),(153.5,104.9)],'CE pullup supply')
via('VDD_3V3',(153.5,104.9),'CE supply transition')
line('VDD_3V3','B.Cu',.2,[(153.5,104.9),(150.9465,104.9)],'CE branch')
# Display supply uses a front-layer cross corridor, with one short underpass at the FPC.
line('VDD_3V3','F.Cu',.4,[(165,109.35),(163.5,107.85),(163.5,106.6),(172,106.6),(179.2,99.4),(182,99.4),(182,97.4)],'LDO to display supply')
line('VDD_3V3','F.Cu',.35,[(182,97.4),(181.65,97.05),(180.25,97.05)],'C9 to U4')
via('VDD_3V3',(183.6,97.4),'retained debug supply transition')
line('VDD_3V3','F.Cu',.35,[(182,97.4),(183.6,97.4)],'display to debug supply')
line('VDD_3V3','B.Cu',.25,[(183.6,97.4),(178.4605,92.2605),(178.4605,81.501)],'debug supply')
# Local returns are explicit; EP is not a destination for every board load.
line('GND','F.Cu',.35,[(167.2,108.4),(168.8,108.4)],'U3 to C4 return')
via('GND',(168.05,108.4),'LDO local ground')
line('GND','F.Cu',.35,[(162.1,109.35),(162.1,108.4),(162.2,108.3),(162.2,107.4)],'C5 C8 local return')
via('GND',(162.2,108.4),'C5 return transition')
line('GND','F.Cu',.35,[(157.2,106.25),(157.2,107.3),(158,107.3),(159.8,107.3),(159.9,107.4),(162.2,107.4)],'U2 EP local return')
via('GND',(159.6,107.3),'charger local return')
line('GND','F.Cu',.35,[(160.8,105.3),(160.8,104.4)],'C2 return')
via('GND',(160.8,104.4),'C2 return transition')
line('GND','F.Cu',.35,[(157.2,102.8),(156.2,102.8)],'C3 return')
via('GND',(156.2,102.8),'C3 return transition')
line('GND','B.Cu',.5,[(156.2,102.8),(154.6,104.4),(154.6,106.3),(155.6,107.3),(159.6,107.3),(162.2,107.3),(163.3,108.4),(168.05,108.4)],'charger and LDO return backbone')
line('GND','F.Cu',.3,[(154.6465,109.6),(153.8,109.6)],'R19 ground')
via('GND',(153.8,109.6),'R19 return transition')
line('GND','B.Cu',.35,[(153.8,109.6),(153.8,107.1),(154.6,106.3)],'TS resistor local return')
# Screen front escape pads and six parallel bottom channels are tested together.
channels=[('EPD_MOSI_TBD',26,172.201,14),('EPD_SCK_TBD',24,173.001,13),('EPD_CS_N_TBD',22,173.801,12),('EPD_DC_TBD',20,174.601,11),('EPD_RESET_N_TBD',19,175.401,10),('EPD_BUSY_TBD',16,177.001,9)]
for i,(net,pin,x,jpin) in enumerate(channels):
 a=(x,112.5)
 if pin==19:
  a=(175.001,116.1)
  line(net,'F.Cu',.15,[(175.001,114.834),a],'RESET inner pad escape')
 else:line(net,'F.Cu',.15,[(x,113.934),a],f'U1.{pin} screen escape')
 via(net,a,'MCU screen transition')
 ey=94.99+i*.5; v=(168+i*.8,ey)
 if pin==19:pts=[a,(176.2,114.901),(176.2,101.9),(173.1,98.8),(173.1,97.69),v]
 else:pts=[a,(x,101.5+i*.4),(x-(101.5+i*.4-ey),ey),v]
 # Normalize the final diagonal with an explicit orthogonal corner.
 if pin==19:pts=[a,(176.2,114.901),(176.2,101.9),(171.29,96.99),(171.2,96.99)]
 line(net,'B.Cu',.15,pts,'screen channel')
 via(net,v,'FPC signal transition')
 line(net,'F.Cu',.15,[v,(166.325,ey)],'FPC signal entry')
# R18 and R17 branch function is retained; unfinished leads remain explicit in native DRC.
line('BAT_NTC_TBD','F.Cu',.15,[(157.2,108.35),(157.2,109.2),(156.8,109.6),(156.1535,109.6)],'TS to R19')
line('BAT_NTC_TBD','F.Cu',.15,[(156.1535,109.6),(156.1535,110.4),(155.5,111.0535),(154,111.0535),(153,110.0535),(153,108.5),(154,107.5)],'independent NTC pad')
# Charging exits change as a group; these are explicit physical witnesses, not ordered search.
charge=[('CHG_SCL',(158,108.35),(158,110),(170.9,116.134),(169.251,116.134),111.3),('CHG_SDA',(157.6,108.35),(157.6,110.9),(166.7136,116.534),(168.351,116.534),112.1),('CHG_PG_N',(158,106.25),(158,105.3),(170.7,116.934),(169.251,116.934),112.9),('CHG_INT_N',(158.4,108.35),(159.2,110.2),(166.8507,116.9015),(168.351,117.334),113.7),('CHG_CE_N',(157.6,106.25),(155.7535,104.9),(167.0905,117.4844),(168.351,118.134),114.5)]
for net,start,v,end,target,y in charge:
 pts=[start,(start[0],v[1]),v] if net!='CHG_CE_N' else [start,(157.6,105.8),(156.7,104.9),v]
 line(net,'F.Cu',.15,pts,'charger pin escape')
 via(net,v,'charger control transition')
 pts=[v,(v[0],y),(end[0]-(end[1]-y),y),end]
 line(net,'B.Cu',.15,pts,'charger west channel')
 via(net,end,'MCU charge transition')
 if net=='CHG_INT_N':pts=[end,(167.3368,116.9015),(167.7693,117.334),target]
 elif net=='CHG_CE_N':pts=[end,(167.7401,118.134),target]
 else:pts=[end,target]
 line(net,'F.Cu',.15,pts,'MCU charge entry')
# USB series are moved together above the MCU, preserving separate pad contacts.
line('USB_DM_MCU','F.Cu',.15,[(166.5,113.2535),(166.5,114.25),(167.184,114.934),(168.351,114.934)],'USB Dminus MCU entry')
line('USB_DP_MCU','F.Cu',.15,[(164.7,113.2535),(164.7,114.4),(166.034,115.734),(168.351,115.734)],'USB Dplus MCU entry')
# Existing ESD-to-connector crossover is retained; output trunks are replaced explicitly.
for x in objects:
 if x['kind'] in ('track','via') and x['net'] in ('USB_DM_CONN','USB_DP_CONN') and x['shape'].bounds[0]<179.7:
  remove_ids.append(x['name'])
line('USB_DP_CONN','F.Cu',.15,[(180,103.45),(179,103.45)],'U5 DP west escape')
line('USB_DM_CONN','F.Cu',.15,[(180,104.15),(179,104.15)],'U5 DM west escape')
for net,at,ry in [('USB_DP_CONN',(179,103.45),111.7465),('USB_DM_CONN',(179,104.15),111.7465)]:via(net,at,'USB west transition')
line('USB_DP_CONN','B.Cu',.15,[(179,103.45),(174,103.45),(165.7035,111.7465),(164.7,111.7465)],'USB DP west trunk')
line('USB_DM_CONN','B.Cu',.15,[(179,104.15),(174.4,104.15),(166.8035,111.7465),(166.5,111.7465)],'USB DM west trunk')
for net,x in [('USB_DP_CONN',164.7),('USB_DM_CONN',166.5)]:
 via(net,(x,110.6),'USB resistor transition')
 line(net,'B.Cu',.15,[(x,111.7465),(x,110.6)],'USB resistor bottom escape')
 line(net,'F.Cu',.15,[(x,110.6),(x,111.7465)],'USB resistor upper pad')
# Exact trial coordinates are checked, including incomplete and conflicting routes.
for r in plan['routes']:
 r['points']=[p for i,p in enumerate(r['points']) if not i or p!=r['points'][i-1]]
(R/'entry-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('removed',len(remove_ids),'routes',len(plan['routes']),'vias',len(plan['vias']))
