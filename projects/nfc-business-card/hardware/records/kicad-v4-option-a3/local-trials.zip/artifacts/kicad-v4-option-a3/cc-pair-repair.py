import sys,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from kicad_sexpr import read,write,children,child,prop
from v4_geometry import geometry
from shapely.geometry import LineString
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local');b=read(p/'NFC-Card-V4.kicad_pcb')
f=next(f for f in children(b,'footprint') if prop(f,'Reference')[2]=='R2');child(f,'at')[:]=['at','181.8','111.8','180']
for pad in children(f,'pad'):
 at=child(pad,'at');at[:]=at[:3]+[str(((float(at[3]) if len(at)>3 else 0)+180)%360)]
ids=[child(x,'uuid')[1] for x in children(b,'segment') if child(x,'net')[-1]=='USB_CC2']
b[:]=[x for x in b if not(isinstance(x,list) and x[0]=='segment' and child(x,'uuid')[1] in ids)]
q=Path('projects/nfc-business-card/artifacts/kicad-v4-option-a3/cc-pair-model.kicad_pcb');write(q,b)
_,pads,objs,_=geometry(q)
routes=[dict(name='CC2 direct approach to rotated R2',net='USB_CC2',layer='F.Cu',width=.15,points=[pads['U6.2']['at'],[184.9317,108.4817],[184.9317,109.7644],[183.7824,110.9137],[183.4398,110.9137],pads['R2.1']['at']]),dict(name='CC resistor shared local return',net='GND',layer='F.Cu',width=.25,points=[pads['R1.2']['at'],[181.3,110.6465],[181.3,111.5465],pads['R2.2']['at']]),dict(name='CC return to existing two-face stitch',net='GND',layer='F.Cu',width=.25,points=[pads['R2.2']['at'],[181.0465,112.2],[181.6465,112.8],[182.55,112.8]])]
errors=[]
for i,r in enumerate(routes):
 for o in objs+[{**x,'name':x['name'],'layers':[x['layer']],'shape':LineString(x['points']).buffer(x['width']/2)} for x in routes[:i]]:
  if o['net']!=r['net'] and r['layer'] in o['layers'] and o['shape'].distance(LineString(r['points']).buffer(r['width']/2))<.2-1e-6:errors.append([r['name'],o['name']])
plan=dict(board=str(p/'NFC-Card-V4.kicad_pcb'),description='A3 jointly orient CC terminations toward U6 and establish their common local ground',record='projects/nfc-business-card/hardware/records/kicad-v4-option-a3/cc-pair-ipc.json',placements={'R2':[181.8,111.8,180]},remove_trial_ids=ids,routes=routes,failures=errors)
(p/'cc-pair-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Conflicts',errors)
