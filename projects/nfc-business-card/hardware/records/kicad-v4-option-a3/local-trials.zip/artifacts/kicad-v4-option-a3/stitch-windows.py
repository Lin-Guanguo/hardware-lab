import sys,importlib.util,json
from pathlib import Path
sys.path.insert(0,'projects/nfc-business-card/scripts')
from shapely.geometry import Point,box
from shapely.ops import unary_union,nearest_points
spec=importlib.util.spec_from_file_location('ground','projects/nfc-business-card/scripts/audit-v4-ground-components.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
spec=importlib.util.spec_from_file_location('router','projects/nfc-business-card/scripts/route-v4-octilinear.py');rt=importlib.util.module_from_spec(spec);spec.loader.exec_module(rt)
p=Path('projects/nfc-business-card/hardware/kicad/v4-option-a3-local/NFC-Card-V4.kicad_pcb')
b,pads,objects,refs,planes,nodes,groups,pg=m.inspect(p)
forbidden=unary_union([*[o['shape'].buffer(.505) for o in objects if o['net']!='GND'],*[o['shape'].buffer(.55) for o in objects if o['kind']=='pad' and len(o['layers'])==1]])
allowed=rt.outline(b).buffer(-.605).difference(forbidden)
cu={i:{l:unary_union([nodes[k] for k in g if k[0]==l]) for l in planes} for i,g in enumerate(groups)}
refs={1:'U6.3',2:'C23.2',3:'SW3.3',4:'C3.2',5:'U1.15',6:'R2.2',7:'J2.17',8:'C25.1',9:'R1.2'}
for i in range(1,len(groups)):
 for j in range(i):
  space=unary_union([cu[i]['F.Cu'].intersection(cu[j]['B.Cu']),cu[i]['B.Cu'].intersection(cu[j]['F.Cu'])]).buffer(-.01).intersection(allowed)
  if not space.is_empty:
   seed=Point(pads[refs[i]]['at']);q=nearest_points(seed,space)[1]
   # Stay inside the legal region instead of selecting an exact numerical boundary.
   qs=space.buffer(-.01);q=nearest_points(seed,qs)[1] if not qs.is_empty else q
   print(i,j,'area',round(space.area,5),'near',list(q.coords[0]),'distance',seed.distance(q))
for i,seeds in [(4,['C3.2','U5.3','U2.11','C2.2']),(1,['U6.3','U1.1','J1.A1B12']),(5,['U1.15']),(7,['J2.17'])]:
 space=unary_union([cu[i]['F.Cu'].intersection(cu[0]['B.Cu']),cu[i]['B.Cu'].intersection(cu[0]['F.Cu'])]).buffer(-.01).intersection(allowed).buffer(-.01)
 print('DETAIL',i,'bounds',space.bounds)
 for s in seeds:
  q=nearest_points(Point(pads[s]['at']),space)[1];print(s,list(q.coords[0]))
